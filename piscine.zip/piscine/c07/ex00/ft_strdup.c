/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ade-assi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 21:02:24 by ade-assi          #+#    #+#             */
/*   Updated: 2024/09/19 21:10:58 by ade-assi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

dest = malloc(sizeof(char) * (5 + 1));

int	main(void)
{
	char	*str = "Salut";
	char	*dest;
	dest = ft_strdup(str);
	printf("%s", dest);
	return (0);
}

